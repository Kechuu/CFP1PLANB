/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import modelo.CodigoPostal;
import modelo.Lugar;

/**
 *
 * @author jesus
 */
public class CtrlLugar {
    
    Connection con = null;
    PreparedStatement ps;
    ResultSet rs;
    
    public void crear(String nombre, int nivel, int de){ //recibe 3 datos
        try {
            con = clases.Conectar.conexion(); //conecta a mysql
            ps = (PreparedStatement) con.prepareStatement("INSERT INTO lugar (nombre, nivel, de) VALUES (?,?,?)"); //guarda un nuevo regist en la tabla lugar
        
            ps.setString(1, nombre.toUpperCase()); //guarda el nombre
            ps.setInt(2, nivel);
            ps.setInt(3, de);
            
            int res = ps.executeUpdate(); //ejecuta el insert
            con.close(); //se cierra la conexion
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getLocalizedMessage()); //si algo falla muestra el error
        }
    }
    
    public void editar(int idLugar, String nombre, int nivel, int de){
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("UPDATE lugar SET nombre = ?, nivel = ?, de = ? WHERE idLugar = ?");
            
            ps.setString(1, nombre.toUpperCase());
            ps.setInt(2, nivel);
            ps.setInt(3, de);
            ps.setInt(4, idLugar);
            
            int res = ps.executeUpdate();
            
            if(res > 0){
                //Nada de Nada :v
            }else{
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios");
            }
            
            con.close();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getLocalizedMessage().toString());
        }
    }
    
    public Lugar leer(int idLugar){//cambie esto, estaba con nivel...<-- Busca y devuelve un objeto lugar
        Lugar lugar = new Lugar(); //crea un objeto vacio
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM lugar WHERE idLugar = ?");//prepara la consulta
            
            ps.setInt(1, idLugar);  //reemplaza parametro
            rs = ps.executeQuery();  //ejecuta el selec
            
            if(rs.next()){  //verifica si encontro datos
                lugar.setIdLugar(rs.getInt("idLugar"));
                lugar.setNombre(rs.getString("nombre"));
                lugar.setNivel(rs.getInt("nivel"));
                lugar.setDe(rs.getInt("de"));
                //si entra al if convierte la fila sql en objeto java
            }else{
                JOptionPane.showMessageDialog(null, "No existe lo que está buscando");
            }
            rs.close();
            con.close();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getLocalizedMessage().toString());
        }
        return lugar; //devuelve el objeto encontrado
    }
    
    public Lugar leer(String nombre, int nivel, int de){ //busca un lugar usando todos los datos
        Lugar lugar = new Lugar();
        
        try {
            con = clases.Conectar.conexion();
            
            ps = (PreparedStatement) con.prepareStatement("SELECT * FROM lugar WHERE nombre = ? AND nivel = ? AND de = ?");
            
            ps.setString(1, nombre.toUpperCase()); //reemplaza parametros
            ps.setInt(2, nivel);
            ps.setInt(3, de);
            
            rs = ps.executeQuery(); //ejecuta consulta
            
            if (rs.next()) {
                lugar.setIdLugar(rs.getInt("idLugar"));
                lugar.setNombre(rs.getString("nombre"));
                lugar.setNivel(rs.getInt("nivel"));
                lugar.setDe(rs.getInt("de"));
            }else{
                JOptionPane.showMessageDialog(null, "No existe lo que está buscando");
            }
            rs.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getLocalizedMessage().toString());
        }
        
        return lugar;
    }
    
    public Lugar leer(String nombre, int nivel){
        Lugar lugar = new Lugar();
        
        try {
            con = clases.Conectar.conexion();
            
            ps = (PreparedStatement) con.prepareStatement("SELECT * FROM lugar WHERE nombre = ? AND nivel = ?");
            
            ps.setString(1, nombre.toUpperCase());
            ps.setInt(2, nivel);
            
            rs = ps.executeQuery();
            
            if (rs.next()) {
                lugar.setIdLugar(rs.getInt("idLugar"));
                lugar.setNombre(rs.getString("nombre"));
                lugar.setNivel(rs.getInt("nivel"));
                lugar.setDe(rs.getInt("de"));
            }else{
                JOptionPane.showMessageDialog(null, "No existe lo que está buscando");
            }
            rs.close();
            con.close();
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null, e.getLocalizedMessage().toString());
        }
        
        return lugar;
    }
    
    
    public Lugar leer(int idLugar, int nivel){
        Lugar lugar = new Lugar();
        
        try {
            con = clases.Conectar.conexion();
            
            ps = (PreparedStatement) con.prepareStatement("SELECT * FROM lugar WHERE idLugar = ? AND nivel = ?");
            
            ps.setInt(1, idLugar);
            ps.setInt(2, nivel);
            
            rs = ps.executeQuery();
            
            if (rs.next()) {
                lugar.setIdLugar(rs.getInt("idLugar"));
                lugar.setNombre(rs.getString("nombre"));
                lugar.setNivel(rs.getInt("nivel"));
                lugar.setDe(rs.getInt("de"));
            }else{
                JOptionPane.showMessageDialog(null, "No existe lo que está buscando");
            }
            rs.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getLocalizedMessage());
        }
        
        return lugar;
    }
    
    public void cargarComboLocalidad(JComboBox<Lugar> comboLocalidad){//Este metodo para llenar el combo con las localidades
        ResultSet rst; //guarda los result del select
        try {
            con= clases.Conectar.conexion();
            ps=(PreparedStatement)con.prepareStatement("SELECT * FROM lugar WHERE nivel = 2 ORDER BY nombre ASC"); //trae solo localid y las ordena alfabeticament
            rst=ps.executeQuery(); //ejecuta el select
            
            Lugar dat= new Lugar(); //crea un objeto
            dat.setIdLugar(0); //configura opcion x defecto
            dat.setNombre("Selecciona una opción..."); //lo cual eso crea esto
            dat.setNivel(0);
            dat.setDe(0);
            comboLocalidad.addItem(dat); //ahora aparece como primer elemento

            while(rst.next()){ //recorre result sql
                dat= new Lugar(); //crea un nuev obj
                
                dat.setIdLugar(rst.getInt("idLugar"));
                dat.setNombre(rst.getString("nombre"));
                dat.setNivel(rst.getInt("nivel"));
                dat.setDe(rst.getInt("de"));
                
                comboLocalidad.addItem(dat); //agrgea cda localidad al combobox
            }
                
        } catch (SQLException ex) {
         
            JOptionPane.showMessageDialog(null, "ERROR AL MOSTRAR Las localidades"+ex.getMessage());
        }
    }
    
    public Vector<Lugar> cargarFiltrado(int de, int nivel) {
        //PreparedStatement ps = null;
        ResultSet rst;
        Vector<Lugar> datos = new Vector<>();
        Lugar dat = null;
        try {
            con = clases.Conectar.conexion();
            String sql = "SELECT * FROM lugar WHERE nivel=? and de =?"; //se agrego ? en de
            
            ps = con.prepareStatement(sql);
            ps.setInt(1, nivel);
            ps.setInt(2, de); //se agrego
            rst = ps.executeQuery();
            dat = new Lugar();
            dat.setIdLugar(0);
            dat.setNombre("Seleccionae una opción...");
            dat.setNivel(0);
            dat.setDe(0);
            datos.add(dat);
                while (rst.next()) {
                    dat = new Lugar();
                    dat.setIdLugar(rst.getInt("idLugar"));
                    dat.setNombre(rst.getString("nombre"));
                    dat.setNivel(rst.getInt("nivel"));
                    dat.setDe(rst.getInt("de"));
                    
                    datos.add(dat);
                }
        } catch (SQLException ex) {
            System.err.println("Error consulta :" + ex.getMessage());
        }
        return datos;
    }
    
    public List<Lugar> cargarListaBarrios(int idLugar){
        List<Lugar> listaBarrio = new ArrayList();
        ResultSet rst;
        con =clases.Conectar.conexion();
        try {
            ps = (PreparedStatement)con.prepareStatement("SELECT * FROM lugar WHERE nivel = 3 AND de = ? ORDER BY nombre ASC");
            
            rst= ps.executeQuery();
            
            while (rst.next()) {
                Lugar lugar = new Lugar();
                lugar.setIdLugar(rst.getInt("idLugar"));
                lugar.setNombre(rst.getString("nombre"));
                lugar.setNivel(rst.getInt("nivel"));
                lugar.setDe(rst.getInt("de"));
                
                listaBarrio.add(lugar);
            } 
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error, "+e);
        }
    return listaBarrio;
    }
    
    
    
    public List<Lugar> llenarTablaBarrio(int idLugar){
        ResultSet rst;
        List<Lugar> lista = new ArrayList();
        con = clases.Conectar.conexion();
        try {
            ps= (PreparedStatement) con.prepareStatement("SELECT * FROM lugar WHERE nivel = 3 AND de = ? ORDER BY nombre ASC");
            
            rst=ps.executeQuery();
            
            while (rst.next()) {
                Lugar lugar = new Lugar();
                lugar.setIdLugar(rst.getInt("idLugar"));
                lugar.setNivel(rst.getInt("nivel"));
                lugar.setNombre(rst.getString("nombre"));
                lugar.setDe(rst.getInt("de"));
                
                lista.add(lugar);
            }
            
        } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "ERROR AL CARGAR LOS BARRIOS EN LA TABLA"+e.getMessage()); 
        }
        return lista;
    }
    
    
    public List<Lugar> llenarTablaCalle(int idLugar){
        ResultSet rst;
        List<Lugar> lista = new ArrayList();
        con = clases.Conectar.conexion();
        try {
            ps= (PreparedStatement) con.prepareStatement("SELECT * FROM lugar WHERE nivel = 4 AND de = ? ORDER BY nombre ASC");
            
            rst=ps.executeQuery();
            
            while (rst.next()) {
                Lugar lugar = new Lugar();
                lugar.setIdLugar(rst.getInt("idLugar"));
                lugar.setNivel(rst.getInt("nivel"));
                lugar.setNombre(rst.getString("nombre"));
                lugar.setDe(rst.getInt("de"));
                
                lista.add(lugar);
            }
            
        } catch (SQLException e) {
             JOptionPane.showMessageDialog(null, "ERROR AL CARGAR LAS CALLES EN LA TABLA"+e.getMessage()); 
        }
        return lista;
    }
    
    public List<Lugar> cargarListaCalles(int idLugar){
        List<Lugar> listaCalle = new ArrayList();
        ResultSet rst;
        con =clases.Conectar.conexion();
        try {
            ps = (PreparedStatement)con.prepareStatement("SELECT * FROM lugar WHERE nivel = 4 AND de = ? ORDER BY nombre ASC");
            
            rst= ps.executeQuery();
            
            while (rst.next()) {
                Lugar lugar = new Lugar();
                lugar.setIdLugar(rst.getInt("idLugar"));
                lugar.setNombre(rst.getString("nombre"));
                lugar.setNivel(rst.getInt("nivel"));
                lugar.setDe(rst.getInt("de"));
                
                listaCalle.add(lugar);
            } 
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error, "+e);
        }
    return listaCalle;
    }
    
    public List<Lugar> cargarListaLocalidades(){
        List<Lugar> listaCalle = new ArrayList();
        ResultSet rst;
        con =clases.Conectar.conexion();
        try {
            ps = (PreparedStatement)con.prepareStatement("SELECT l.idLugar, l.nombre, cp.codigoPostal\n" +
"FROM lugar l\n" +
"INNER JOIN codigoPostal cp\n" +  //estooo se modificoooooooooooooooooooo
"ON cp.idLugar = l.idLugar\n" +
"WHERE l.nivel = 3\n" +
"ORDER BY l.nombre ASC + " );
            
            rst= ps.executeQuery();
            
            while (rst.next()) {
                Lugar lugar = new Lugar();
                lugar.setIdLugar(rst.getInt("idLugar"));
                lugar.setNombre(rst.getString("nombre"));
                lugar.setDe(rst.getInt("de"));
                
                listaCalle.add(lugar);
            } 
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error, "+e);
        }
    return listaCalle;
    }
    
    public List<String> llenarTablaLocalidades(int nivel){

    ResultSet rst;
    List<String> lista = new ArrayList<>();

    try {
        con = clases.Conectar.conexion();

        String sql =
        "SELECT l.nombre, cp.codigoPostal " +
        "FROM lugar l " +
        "INNER JOIN codigoPostal cp " +
        "ON cp.idLugar = l.idLugar " +
        "WHERE l.nivel = ? " +
        "ORDER BY l.nombre ASC";

        ps = con.prepareStatement(sql);
        ps.setInt(1, nivel);

        rst = ps.executeQuery();

        while (rst.next()) {
            lista.add(rst.getString("nombre"));
            lista.add(rst.getString("codigoPostal"));
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null,
            "ERROR AL CARGAR LOCALIDADES: " + e.getMessage());
    }

    return lista;
}  //metodoooo corregiddoooooooooooooooooooooooooooooooooooooooooooooo
    
}

