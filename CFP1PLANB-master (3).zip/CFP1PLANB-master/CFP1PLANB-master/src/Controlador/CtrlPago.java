/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import modelo.Pago;
/**
 *
 * @author jesus
 */
public class CtrlPago {
    
    Connection con = null;
    PreparedStatement ps;
    ResultSet rs;
    
    public void crear(java.util.Date fecha, float importe, int Empleado_idEmpleado, int CursoAlumno_idCursoAlumno){
        java.sql.Date fe=new Date(fecha.getTime());
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("INSERT INTO pago (fecha,importe,Empleado_idEmpleado, CursoAlumno_idCursoAlumno) "
                    + "VALUES (?,?,?,?)");
        
            ps.setDate(1, fe);
            ps.setFloat(2, importe);
            ps.setInt(3, Empleado_idEmpleado);
            ps.setInt(4, CursoAlumno_idCursoAlumno);
            
            int res = ps.executeUpdate();
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlPago: " + e.getMessage());
        }
    }
    
    public Pago leer(int idPago){
        Pago pago = new Pago();
        CtrlEmpleado ctrlCobrador = new CtrlEmpleado();
        CtrlCursoAlumno ctrlCursoAlumno = new CtrlCursoAlumno();
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM pago WHERE idPago = ?");
            
            ps.setInt(1, idPago);
            
            rs = ps.executeQuery();
            
            if (rs.next()) {
                pago.setFecha(rs.getDate("fecha"));
                pago.setImporte(rs.getFloat("importe"));
                pago.setIdCobrador(ctrlCobrador.leer(rs.getInt("idEmpleado")));
                //pago.setIdCursoAlumno(ctrlCursoAlumno.leer(rs.getInt("CursoAlumno_idCursoAlumno")));
            }else{
                System.out.println("No encontrado en CtrlPago.java");
            }
            
        } catch (Exception e) {
            System.out.println("Error CtrlPago: " + e.getMessage());
        }
        return pago;
    }
}
