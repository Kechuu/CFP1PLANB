/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import modelo.EmpleadoTitulo;
import modelo.PlanPersona;
import modelo.Planes;
import modelo.Titulo;
/**
 *
 * @author jesus
 */
public class CtrlEmpleadoTitulo {
    
    Connection con = null;
    PreparedStatement ps;
    ResultSet rs;
    
    public void crear(int Titulo_idTitulo, int Empleado_idEmpleado){
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("INSERT INTO empleadoTitulo (Titulo_idTitulo, Empleado_idEmpleado) VALUES (?,?)");
        
            ps.setInt(1, Titulo_idTitulo);
            ps.setInt(2, Empleado_idEmpleado);
            
            int res = ps.executeUpdate();
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlEmpleadoTitulo: " + e.getMessage());
        }
    }
    
    public void editar(int Empleado_idEmpleadoTitulo, int Titulo_idTitulo, int Empleado_idEmpleado){
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("UPDATE empleadoTitulo SET Titulo_idTitulo = ? WHERE Empleado_idEmpleadoTitulo = ? AND Empleado_idEmpleado = ? ");
        
            ps.setInt(1, Titulo_idTitulo);
            ps.setInt(2, Empleado_idEmpleadoTitulo);
            ps.setInt(3, Empleado_idEmpleado);
             int res = ps.executeUpdate();
            
            if(res > 0){
                //Nada de Nada :v
            }else{
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios");
            }
            
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlEmpleadoTitulo: " + e.getMessage());
        }
    }
    
    public void borrar(int Empleado_idEmpleadoTitulo, int Titulo_idTitulo, int Empleado_idEmpleado){
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("DELETE FROM empleadoTitulo WHERE Empleado_idEmpleadoTitulo=? AND Empleado_idEmpleado=? AND Titulo_idTitulo=?");
            
            ps.setInt(1, Empleado_idEmpleadoTitulo);
            ps.setInt(2, Empleado_idEmpleado);
            ps.setInt(3, Titulo_idTitulo);
            
            int res = ps.executeUpdate();
            
            if(res > 0){
                //Nada de Nada :v
            }else{
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios");
            }
            
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlEmpleadoTitulo: " + e.getMessage());
        }
    }
    
    public EmpleadoTitulo leer(int Empleado_idEmpleadoTitulo){
        EmpleadoTitulo empleadoTitulo = new EmpleadoTitulo();
        CtrlTitulo ctrlTitulo = new CtrlTitulo();
        CtrlEmpleado ctrlEmpleado = new CtrlEmpleado();
        
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM empleadoTitulo WHERE Empleado_idEmpleadoTitulo = ?");
            
            ps.setInt(1, Empleado_idEmpleadoTitulo);
            
            rs = ps.executeQuery();
            
            if (rs.next()) {
                empleadoTitulo.setIdTitulo(ctrlTitulo.leer(rs.getInt("Titulo_idTitulo")));
                empleadoTitulo.setIdEmpleado(ctrlEmpleado.leer(rs.getInt("Empleado_idEmpleado")));
            }else{
                System.out.println("No encontrado en CtrlEmpleadoTitulo.java");
            }
            
        } catch (Exception e) {
            System.out.println("Error CtrlEmpleadoTitulo: " + e.getMessage());
        }
        return empleadoTitulo;
    }
    
    public EmpleadoTitulo leer(int Empleado_idEmpleado, int Titulo_idTitulo){
        
        EmpleadoTitulo empleadoTitulo=null;
        CtrlTitulo ctrlTitulo=new CtrlTitulo();
        CtrlEmpleado ctrlEmpleado=new CtrlEmpleado();
        
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM empleadoTitulo WHERE Empleado_idEmpleado = ? AND Titulo_idTitulo=?");
            
            ps.setInt(1, Empleado_idEmpleado);
            ps.setInt(2, Titulo_idTitulo);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                empleadoTitulo=new EmpleadoTitulo();
                
                empleadoTitulo.setIdEmpleadoTitulo(rs.getInt("Empleado_idEmpleadoTitulo"));
                empleadoTitulo.setIdEmpleado(ctrlEmpleado.leerIdEmpleado(rs.getInt("Empleado_idEmpleado")));
                empleadoTitulo.setIdTitulo(ctrlTitulo.leer(rs.getInt("Titulo_idTitulo")));
                
            }    
            con.close();
        } catch (SQLException e) {
            System.out.println("Error CtrlEmpleadoTitulo: " + e.getMessage());
        }
        
        return empleadoTitulo;
    }
    
    
    public void llenarLista(int Empleado_idEmpleado, JList <Titulo> lista){
        CtrlTitulo ctrlTitulo=new CtrlTitulo();
        EmpleadoTitulo empleadoTitulo;
        
        DefaultListModel<Titulo> modelo=new DefaultListModel<>();
        
        try{
            con=clases.Conectar.conexion();
            ps=(PreparedStatement)con.prepareStatement("SELECT * FROM empleadoTitulo WHERE Empleado_idEmpleado=?");
            ps.setInt(1, Empleado_idEmpleado);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                empleadoTitulo=new EmpleadoTitulo();
                
                empleadoTitulo.setIdTitulo(ctrlTitulo.leer(rs.getInt("Titulo_idTitulo")));                
                modelo.addElement(empleadoTitulo.getIdTitulo());
                
            }
            
            lista.setModel(modelo);
            con.close();
        }catch(SQLException e){
            
        }
        
    }
}
