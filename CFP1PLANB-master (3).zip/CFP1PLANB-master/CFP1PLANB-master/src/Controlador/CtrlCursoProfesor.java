/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.Caracter;
import modelo.CursoProfesor;
import modelo.TipoCurso;

/**
 *
 * @author jesus
 */
public class CtrlCursoProfesor {

    Connection con = null;
    PreparedStatement ps;
    ResultSet rs;

    public void crear(int Curso_idCurso, int Empleado_idEmpleado, int Caracter_idCaracter) {
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("INSERT INTO cursoProfesor (Curso_idCurso, Empleado_idEmpleado, Caracter_idCaracter) VALUES (?,?,?)");

            ps.setInt(1, Curso_idCurso);
            ps.setInt(2, Empleado_idEmpleado);
            ps.setInt(3, Caracter_idCaracter);

            int res = ps.executeUpdate();
            con.close();

        } catch (Exception e) {
            System.out.println("Error CtrlCursoProfesor: " + e.getMessage());
        }
    }

    public void cambiarProfesorCurso(int Curso_idCurso, int idCursoProfesor, int Empleado_idEmpleado) {
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("UPDATE cursoProfesor SET Curso_idCurso = ? WHERE idCursoProfesor = ? "
                    + "AND Empleado_idEmpleado = ?");

            ps.setInt(1, Curso_idCurso);
            ps.setInt(2,idCursoProfesor);
            ps.setInt(3, Empleado_idEmpleado);

            int res = ps.executeUpdate();

            if (res > 0) {
                //Nada de Nada :v
            } else {
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios");
            }

            con.close();

        } catch (Exception e) {
            System.out.println("Error CtrlCursoProfesor: " + e.getMessage());
        }
    }

    public void borrar(int Empleado_idEmpleado, int Curso_idCurso) {

        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("DELETE FROM cursoProfesor WHERE Empleado_idEmpleado=? AND Curso_idCurso=?");

            ps.setInt(1, Empleado_idEmpleado);
            ps.setInt(2, Curso_idCurso);

            int res = ps.executeUpdate();

            if (res > 0) {
                JOptionPane.showMessageDialog(null, "Se dio de baja");
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo dar de baja");
            }
        } catch (HeadlessException | SQLException e) {
            System.out.println("Error CtrlCursoProfesor: " + e.getMessage());
        }
    }

    public CursoProfesor leer(int idCursoProfesor) {
        CursoProfesor cursoProfesor = new CursoProfesor();
        CtrlCurso ctrlCurso = new CtrlCurso();
        CtrlEmpleado ctrlEmpleado = new CtrlEmpleado();
        CtrlCaracter ctrlCaracter = new CtrlCaracter();

        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("SELECT * FROM cursoProfesor WHERE idCursoProfesor = ?");

            ps.setInt(1, idCursoProfesor);

            rs = ps.executeQuery();

            if (rs.next()) {
                cursoProfesor.setIdCurso(ctrlCurso.leer(rs.getInt("Curso_idCurso")));
                cursoProfesor.setIdEmpleado(ctrlEmpleado.leer(rs.getInt("Empleado_idEmpleado")));
                cursoProfesor.setIdCaracter(ctrlCaracter.leer(rs.getInt("Caracter_idCaracter")));
            } else {
                System.out.println("No encontrado en CtrlCursoProfesor.java");
            }

        } catch (Exception e) {
            System.out.println("Error CtrlCursoProfesor: " + e.getMessage());
        }
        return cursoProfesor;
    }

    public CursoProfesor leerCurso(int Curso_idCurso, int Empleado_idEmpleado) {
        CursoProfesor cursoProfesor = new CursoProfesor();
        CtrlCurso ctrlCurso = new CtrlCurso();
        CtrlEmpleado ctrlEmpleado = new CtrlEmpleado();
        CtrlCaracter ctrlCaracter = new CtrlCaracter();

        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("SELECT * FROM cursoProfesor WHERE Curso_idCurso = ? AND Empleado_idEmpleado = ?");

            ps.setInt(1, Curso_idCurso);
            ps.setInt(2, Empleado_idEmpleado);

            rs = ps.executeQuery();

            if (rs.next()) {
                cursoProfesor.setIdCursoProfesor(rs.getInt("idCursoProfesor"));
                cursoProfesor.setIdCurso(ctrlCurso.leer(rs.getInt("Curso_idCurso")));
                cursoProfesor.setIdEmpleado(ctrlEmpleado.leer(rs.getInt("Empleado_idEmpleado")));
                cursoProfesor.setIdCaracter(ctrlCaracter.leer(rs.getInt("Caracter_idCaracter")));
            } else {
                System.out.println("No encontrado en CtrlCursoProfesor.java");
            }
            con.close();
        } catch (Exception e) {
            System.out.println("Error CtrlCursoProfesor: " + e.getMessage());
        }
        return cursoProfesor;
    }

    public void llenarLista(int Empleado_idEmpleado, JList<TipoCurso> lista) {
        //Este metodo llena lista de los cursos que esta cursando actualmente un determinado empleado
        DefaultListModel<TipoCurso> modelo = new DefaultListModel<>();

        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("SELECT tipoCurso.idTipoCurso, tipoCurso.detalle FROM cursoProfesor"
        + " INNER JOIN curso ON cursoProfesor.Curso_idCurso = curso.idCurso"
        + " INNER JOIN tipoCurso ON curso.TipoCurso_idTipoCurso = tipoCurso.idTipoCurso"
        + " WHERE cursoProfesor.Empleado_idEmpleado = ?");

            ps.setInt(1, Empleado_idEmpleado);

            rs = ps.executeQuery();

            while (rs.next()) {
                TipoCurso tipoCurso = new TipoCurso();

                tipoCurso.setIdTipoCurso(rs.getInt("idTipoCurso"));
                tipoCurso.setDetalle(rs.getString("detalle"));

                modelo.addElement(tipoCurso);
            }
            lista.setModel(modelo);

            con.close();
        } catch (Exception e) {
            System.out.println("Error CtrlCursoProfesor: " + e.getMessage());
        }

    }

    public void llenarTabla(int Empleado_idEmpleado, JTable tabla) throws SQLException {
        //CAMBIAR PARA QUE LLENE SEGUN EL EMPLEADO Y NO SEGUN EL ALUMNO..    
        con = clases.Conectar.conexion();

        ps = (PreparedStatement) con.prepareStatement("SELECT tipoCurso.detalle, cargo.detalle, estadoEmpleado.detalle FROM tipoCurso "
        + " INNER JOIN curso ON tipoCurso.idTipoCurso = curso.TipoCurso_idTipoCurso"
        + " INNER JOIN cursoProfesor ON curso.idCurso = cursoProfesor.Curso_idCurso"
        + " INNER JOIN empleado ON cursoProfesor.Empleado_idEmpleado = empleado.idEmpleado"
        + " INNER JOIN empleadoCargo ON empleado.idEmpleado = empleadoCargo.Empleado_idEmpleado"
        + " INNER JOIN cargo ON empleadoCargo.Cargo_idCargo = cargo.idCargo"
        + " INNER JOIN estadoEmpleado ON empleado.idEstadoEmpleado = estadoEmpleado.idEstadoEmpleado"
        + " WHERE empleado.idEmpleado=?");

        ps.setInt(1, Empleado_idEmpleado);

        rs = ps.executeQuery();

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Nombre");
        modelo.addColumn("Cargo");
        modelo.addColumn("Estado empleado");

        tabla.setModel(modelo);

        String[] datos = new String[3];
        try {

            while (rs.next()) {

                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);

                modelo.addRow(datos);
            }

            con.close();
            tabla.setModel(modelo);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "ERROR AL CARGAR LAS LOCALIDADES EN LA TABLA");
        }

    }

    public List<CursoProfesor> cargarListaCursoProfesor(int Empleado_idEmpleado, int Caracter_idCaracter) {
        List<CursoProfesor> listaCursoProfesor = new ArrayList();
        CtrlEmpleado ctrlEmpleado = new CtrlEmpleado();
        CtrlCurso ctrlCurso = new CtrlCurso();
        CtrlCaracter ctrlCaracter = new CtrlCaracter();
        ResultSet rst;
        con = clases.Conectar.conexion();
        try {
            ps = (PreparedStatement) con.prepareStatement("SELECT * FROM cursoProfesor WHERE Empleado_idEmpleado = ? AND Caracter_idCaracter = ?");
            ps.setInt(1, Empleado_idEmpleado);
            ps.setInt(2, Caracter_idCaracter);

            rst = ps.executeQuery();

            while (rst.next()) {
                CursoProfesor cursoProfesor = new CursoProfesor();
                cursoProfesor.setIdCursoProfesor(rst.getInt("idCursoProfesor"));
                cursoProfesor.setIdEmpleado(ctrlEmpleado.leerIdEmpleado(rst.getInt("Empleado_idEmpleado")));
                cursoProfesor.setIdCurso(ctrlCurso.leerCurso(rst.getInt("Curso_idCurso")));
                cursoProfesor.setIdCaracter(ctrlCaracter.leer(rst.getInt("Caracter_idCaracter")));

                listaCursoProfesor.add(cursoProfesor);
            }
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error, " + e);
        }
        return listaCursoProfesor;
    }

    public void cargarCombo(JComboBox<Caracter> cbCursoProfesor, int Empleado_idEmpleado) {
        cbCursoProfesor.removeAllItems();
        CtrlCurso ctrlCurso = new CtrlCurso();
        CtrlEmpleado ctrlEmpleado = new CtrlEmpleado();
        CtrlCaracter ctrlCaracter = new CtrlCaracter();
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("SELECT DatosCFP.cursoProfesor.Caracter_idCaracter FROM DatosCFP.cursoProfesor "
                    + "WHERE DatosCFP.cursoProfesor.Empleado_idEmpleado = ?");
            ps.setInt(1, Empleado_idEmpleado);

            rs = ps.executeQuery();

            Caracter caracter2 = new Caracter();
            Caracter caracter = new Caracter();
            caracter2.setIdCaracter(0);
            caracter2.setDetalle("Seleciione un caracter...");
            cbCursoProfesor.addItem(caracter2);

            while (rs.next()) {

                caracter = new Caracter();
                caracter2 = new Caracter();

                caracter = ctrlCaracter.leer(rs.getInt("Caracter_idCaracter"));

                caracter2.setIdCaracter(caracter.getIdCaracter());
                caracter2.setDetalle(caracter.getDetalle());

                cbCursoProfesor.addItem(caracter2);
            }
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "ERROR AL MOSTRAR Tipo de Documento: " + e.getMessage());
        }

    }

    public void borradoLogicoGeneral(int Empleado_idEmpleado) {
        CursoProfesor cursoProfesor;
        CtrlCurso ctrlCurso = new CtrlCurso();
        CtrlEmpleado ctrlEmpleado = new CtrlEmpleado();
        CtrlPersona ctrlPersona = new CtrlPersona();

        Vector<CursoProfesor> vector = new Vector<>();

        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("SELECT * FROM cursoProfesor "
                    + " WHERE Empleado_idEmpleado = ?");
            ps.setInt(1, Empleado_idEmpleado);
            rs = ps.executeQuery();

            while (rs.next()) {
                cursoProfesor = new CursoProfesor();

                cursoProfesor.setIdCursoProfesor(rs.getInt("idCursoProfesor"));
                cursoProfesor.setIdCurso(ctrlCurso.leerCurso(rs.getInt("Curso_idCurso")));

                vector.add(cursoProfesor);
            }

            for (int i = 0; i < vector.size(); i++) {
                borrar(Empleado_idEmpleado, vector.get(i).getIdCurso().getIdCurso());
            }

            java.util.Date fecha = new Date();
            int idPersona = ctrlEmpleado.leerIdEmpleado(Empleado_idEmpleado).getIdPersona().getIdPersona();
            ctrlEmpleado.darDeBaja(fecha, idPersona, 2);
            ctrlPersona.borrar(idPersona);

            con.close();
        } catch (SQLException e) {

        }
    }

}
