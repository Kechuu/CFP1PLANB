/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import modelo.EstadoAlumno;
/**
 *
 * @author jesus
 */
public class CtrlEstadoAlumno {
    Connection con = null;
    PreparedStatement ps;
    ResultSet rs;
    
    public void crear(String detalle){
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("INSERT INTO estadoAlumno (detalle) VALUES (?)");
        
            ps.setString(1, detalle.toUpperCase());
            
            int res = ps.executeUpdate();
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlEstadoAlumno: " + e.getMessage());
        }
    }
    
    public void editarEstadoAlumno(int idEstadoAlumno, String detalle){
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("UPDATE estadoAlumno SET detalle = ? WHERE idEstadoAlumno = ?");
            
            ps.setString(1, detalle);
            ps.setInt(2, idEstadoAlumno);
            
            int res = ps.executeUpdate();
            
            if(res > 0){
                //Nada de Nada :v
            }else{
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios");
            }
            
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlEstadoAlumno: " + e.getMessage());
        }
    }
    
    public EstadoAlumno leer(int idEstadoAlumno){
        EstadoAlumno estadoAlumno = new EstadoAlumno();
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM estadoAlumno WHERE idEstadoAlumno = ?");
            
            ps.setInt(1, idEstadoAlumno);
            rs = ps.executeQuery();
            
            if(rs.next()){
                estadoAlumno.setIdEstadoAlumno(rs.getInt("idEstadoAlumno"));
                estadoAlumno.setDetalle(rs.getString("detalle"));
            }else{
                System.out.println("No encontrado en CtrlEstadoAlumno.java");
            }
            
            con.close();
        }catch(Exception e){
            System.out.println("Error CtrlEstadoAlumno: " + e.getMessage());
        }
        return estadoAlumno;
    }
}
