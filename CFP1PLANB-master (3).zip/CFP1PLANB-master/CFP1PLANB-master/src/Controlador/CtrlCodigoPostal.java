/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import modelo.CodigoPostal;
import modelo.Lugar;
/**
 *
 * @author jesus
 */
public class CtrlCodigoPostal {
    Connection con = null;
    PreparedStatement ps;
    ResultSet rs;
    
    public void crear(int idLocalidad, String codigoPostal){
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("INSERT INTO codigoPostal (Lugar_idLugar,codigoPostal) VALUES (?,?)");
            
            ps.setInt(1, idLocalidad);
            ps.setString(2, codigoPostal);
            
            int res = ps.executeUpdate();
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlCodigoPostal: " + e.getMessage());
        }
    }
    
    public void editar(int idLocalidad, String codigoPostal){
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("UPDATE codigoPostal SET codigoPostal = ? WHERE Lugar_idLugar = ?");
            
            ps.setString(1, codigoPostal);
            ps.setInt(2, idLocalidad);
            
            int res = ps.executeUpdate();
            
            if (res > 0) {
                //Nada de Nada :v
            }else{
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios");
            }
            
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlCodigoPostal: " + e.getMessage());
        }
    }
    
    public CodigoPostal leer(int idLocalidad){
        CodigoPostal codigoPostal = new CodigoPostal();
        CtrlLugar ctrlLugar = new CtrlLugar();
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM codigoPostal WHERE Lugar_idLugar = ?");
            
            ps.setInt(1, idLocalidad);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                codigoPostal.setIdCodigoPostal(rs.getInt("idCodigoPostal"));
                //codigoPostal.setLocalidad(ctrlLugar.leer(rs.getInt("localidad"), 3));
                codigoPostal.setCodigoPostal(rs.getString("codigoPostal"));
            }else{
                System.out.println("No encontrado en CtrlCodigoPostal.java");
            }
            
        } catch (Exception e) {
            System.out.println("Error CtrlCodigoPostal: " + e.getMessage());
        }
        return codigoPostal;
    }
}
