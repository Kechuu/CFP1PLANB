/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import modelo.EmpleadoLicencia;
/**
 *
 * @author jesus
 */
public class CtrlEmpleadoLicencia {
    
    Connection con = null;
    PreparedStatement ps;
    ResultSet rs;
    
    public void crear(java.sql.Date inicio, java.sql.Date fin, int Empleado_idEmpleado, int Licencia_idLicencia, int Caracter_idCaracter, int Curso_idCurso){
    try {
        con = clases.Conectar.conexion();
        ps = (PreparedStatement) con.prepareStatement("INSERT INTO empleadoLicencia (inicio,fin, Empleado_idEmpleado, Licencia_idLicencia, Caracter_idCaracter, Curso_idCurso) VALUES (?,?,?,?,?,?)");
        ps.setDate(1, inicio);
        ps.setDate(2, fin);
        ps.setInt(3, Empleado_idEmpleado);
        ps.setInt(4, Licencia_idLicencia);
        ps.setInt(5, Caracter_idCaracter);
        ps.setInt(6, Curso_idCurso);
        ps.executeUpdate();
        con.close();
    } catch (Exception e) {
        System.out.println("Error CtrlEmpleadoLicencia: " + e.getMessage());
    }
}
    
    public void finDeLicencia(int Empleado_idEmpleadoLicencia ,int Empleado_idEmpleado ,Date fin, int Curso_idCurso){
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("UPDATE empleadoLicencia SET fin = ? WHERE Empleado_idEmpleadoLicencia = ? AND Empleado_idEmpleado = ? AND Curso_idCurso = ?");
        
            ps.setDate(1, fin);
            ps.setInt(2, Empleado_idEmpleadoLicencia);
            ps.setInt(3, Empleado_idEmpleado);
            ps.setInt(4, Curso_idCurso);
            
             int res = ps.executeUpdate();
            
            if(res > 0){
                //Nada de Nada :v
            }else{
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios");
            }
            
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlEmpleadoLicencia: " + e.getMessage());
        }
    }
    
    public EmpleadoLicencia leer(int Empleado_idEmpleadoLicencia){
        EmpleadoLicencia empleadoLicencia = new EmpleadoLicencia();
        CtrlEmpleado ctrlEmpleado = new CtrlEmpleado();
        CtrlLicencia ctrlLicencia = new CtrlLicencia();
        CtrlCaracter ctrlCaracter = new CtrlCaracter();
        CtrlCurso ctrlCurso = new CtrlCurso();
        
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM empleadoLicencia WHERE Empleado_idEmpleadoLicencia = ?");
            
            ps.setInt(1, Empleado_idEmpleadoLicencia);
            
            rs = ps.executeQuery();
            
            if (rs.next()) {
                empleadoLicencia.setInicio(rs.getDate("inicio"));
                empleadoLicencia.setFin(rs.getDate("fin"));
                empleadoLicencia.setIdEmpleado(ctrlEmpleado.leer(rs.getInt("Empleado_idEmpleado")));
                empleadoLicencia.setIdLicencia(ctrlLicencia.leer(rs.getInt("Licencia_idLicencia")));
                empleadoLicencia.setIdCaracter(ctrlCaracter.leer(rs.getInt("Caracter_idCaracter")));
                empleadoLicencia.setIdCurso(ctrlCurso.leerCurso(rs.getInt("Curso_idCurso")));
                
            }else{
                System.out.println("No encontrado en CtrlEmpleadoLicencia.java");
            }
            
        } catch (Exception e) {
            System.out.println("Error CtrlEmpleadoLicencia: " + e.getMessage());
        }
        return empleadoLicencia;
    }
}
