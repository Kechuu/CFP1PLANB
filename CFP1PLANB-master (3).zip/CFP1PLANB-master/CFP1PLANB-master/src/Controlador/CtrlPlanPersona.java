/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.PlanPersona;
import modelo.Planes;
/**
 *
 * @author jesus
 */
public class CtrlPlanPersona {
    
    Connection con = null;
    PreparedStatement ps;
    ResultSet rs;
    
    public void crear(int Persona_idPersona, int Planes_idPlanes){
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("INSERT INTO planPersona (Persona_idPersona,Planes_idPlanes) VALUES (?,?)");
        
            ps.setInt(1, Persona_idPersona);
            ps.setInt(2, Planes_idPlanes);
            
            int res = ps.executeUpdate();
            con.close();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"clase control plan persona");
            System.out.println("Error CtrlPlanPersona: " + e.getMessage());
        }
    }
    
    public void editar(int idPlanPersona, int Persona_idPersona, int Planes_idPlanes){
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("UPDATE planPersona SET Planes_idPlanes=? WHERE idPlanPersona = ? AND Persona_idPersona = ?");
            
            ps.setInt(1, Planes_idPlanes);
            ps.setInt(2, idPlanPersona);
            ps.setInt(3, Persona_idPersona);
            
            int res = ps.executeUpdate();
            
            if(res > 0){
                //Nada de Nada :v
            }else{
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios ES AQUIA");
            }
            
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlPlanPersona: " + e.getMessage());
        }
    }
    
    public void borrar(int idPlanPersona, int idPlan, int Persona_idPersona){
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("DELETE FROM planPersona WHERE idPlanPersona=? AND Persona_idPersona=? AND Planes_idPlanes=?");
            
            ps.setInt(1, idPlanPersona);
            ps.setInt(2, Persona_idPersona);
            ps.setInt(3, idPlan);
            
            int res = ps.executeUpdate();
            
            if(res > 0){
                //Nada de Nada :v
            }else{
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios");
            }
            
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlPlanPersona: " + e.getMessage());
        }
    }
    
    public PlanPersona leer(int Persona_idPersona, int idPlan){
        PlanPersona planPersona = new PlanPersona();
        CtrlPersona ctrlPersona = new CtrlPersona();
        CtrlPlanes ctrlPlanes = new CtrlPlanes();
        
        //JOptionPane.showMessageDialog(null, "persona "+Persona_idPersona+" plan"+idPlan);
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM planPersona WHERE Persona_idPersona = ? AND Planes_idPlanes=?");
            
            ps.setInt(1, Persona_idPersona);
            ps.setInt(2, idPlan);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                planPersona=new PlanPersona();
                
                planPersona.setIdPlanPersona(rs.getInt("idPlanPersona"));
                planPersona.setIdPersona(ctrlPersona.leer(rs.getInt("Persona_idPersona")));
                planPersona.setIdPlanes(ctrlPlanes.leer(rs.getInt("Planes_idPlanes")));
                
                //JOptionPane.showMessageDialog(null, planPersona.getIdPlanPersona()+"id persona "+planPersona.getIdPersona()+" plan"+planPersona.getIdPlanes());
            }    
            con.close();
        } catch (SQLException e) {
            System.out.println("Error CtrlPlanPersona: " + e.getMessage());
        }
        
        return planPersona;
    }
    
    public void llenarLista(int Persona_idPersona, JList <Planes> lista){
        CtrlPlanes ctrlPlanes=new CtrlPlanes();
        PlanPersona planPersona;
        
        DefaultListModel<Planes> modelo=new DefaultListModel<>();
        
        try{
            con=clases.Conectar.conexion();
            ps=(PreparedStatement)con.prepareStatement("SELECT * FROM planPersona WHERE Persona_idPersona = ?");
            ps.setInt(1, Persona_idPersona);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                planPersona=new PlanPersona();
                
                planPersona.setIdPlanes(ctrlPlanes.leer(rs.getInt("Planes_idPlanes")));
                
                modelo.addElement(planPersona.getIdPlanes());
                
            }
            
            lista.setModel(modelo);
            con.close();
        }catch(SQLException e){
            
        }
        
    }
    public void llenarTabla(int Persona_idPersona, JTable tabla) throws SQLException{
        
        con=clases.Conectar.conexion();
    
        ps=(PreparedStatement)con.prepareStatement("SELECT planes.detalle FROM planes "
                + " INNER JOIN planPersona ON planes.idPlanes=planPersona.Planes_idPlanes "
                + " WHERE planPersona.Persona_idPersona=?");
        
        ps.setInt(1, Persona_idPersona);
        
        rs=ps.executeQuery();
        
        DefaultTableModel modelo =new DefaultTableModel();
        modelo.addColumn("Planes");
        
        tabla.setModel(modelo);
        
        String[] datos= new String[1];
        try{
            
            while(rs.next()){
                
	            datos[0]=rs.getString(1);
	            
            	    modelo.addRow(datos);
            }

             tabla.setModel(modelo);
         }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "ERROR AL CARGAR LAS LOCALIDADES EN LA TABLA"); 
        }
        
    }
}
