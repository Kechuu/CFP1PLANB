/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.Edificio;

/**
 *
 * @author jesus
 */
public class CtrlEdificio {
    Connection con = null;
    PreparedStatement ps;
    ResultSet rs;
    
    public void crear(String bloque, String piso, String depto){
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("INSERT INTO edificio (Torre,Piso,Dpto) VALUES (?,?,?)");
        
            ps.setString(1, bloque);
            ps.setString(2, piso);
            ps.setString(3, depto);
            
            int res = ps.executeUpdate();
            con.close();
            
        } catch (SQLException e) {
            System.out.println("Error CtrlEdificio.crear: " + e.getMessage());
        }
    }
    
    public void editar(String bloque, String piso, String depto, int idEdificio){
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("UPDATE edificio SET Torre = ?,Piso = ? ,Dpto = ? WHERE idEdificio = ?");
            
            ps.setString(1, bloque);
            ps.setString(2, piso);
            ps.setString(3, depto);
            ps.setInt(4, idEdificio);
            
            int res = ps.executeUpdate();
            
            if(res > 0){
                //Nada de Nada :v
            }else{
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios");
            }
            
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlEdificio: " + e.getMessage());
        }
    }
    
    public Edificio leer(int idEdificio){
        Edificio edificio = new Edificio();
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM edificio WHERE idEdificio = ?");
            
            ps.setInt(1,idEdificio);
            rs = ps.executeQuery();
            
            if(rs.next()){
                edificio.setIdEdificio(rs.getInt("idEdificio"));
                edificio.setDepto(rs.getString("Dpto"));
                edificio.setPiso(rs.getString("Piso"));
                edificio.setTorre(rs.getString("Torre"));
            }else{
                System.out.println("No encontrado en CtrlEdificio.java");
            }
            
            con.close();
        }catch(Exception e){
            System.out.println("Error CtrlEdificio: " + e.getMessage());
        }
        return edificio;
    }
    
    public Edificio leer(){
        Edificio edificio = new Edificio();
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM edificio ORDER BY idEdificio DESC LIMIT 1 ");
            
           // ps.setInt(1,idEdificio);
            rs = ps.executeQuery();
            
            if(rs.next()){
                edificio.setIdEdificio(rs.getInt("idEdificio"));
                edificio.setDepto(rs.getString("Dpto"));
                edificio.setPiso(rs.getString("Piso"));
                edificio.setTorre(rs.getString("Torre"));
            }else{
                System.out.println("No encontrado en CtrlEdificio.java");
            }
            
            con.close();
        }catch(Exception e){
            System.out.println("Error CtrlEdificio: " + e.getMessage());
        }
        return edificio;
    }
}
