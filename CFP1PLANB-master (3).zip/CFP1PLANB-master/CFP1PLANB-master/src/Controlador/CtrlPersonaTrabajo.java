/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.PersonaTrabajo;
import modelo.Trabajo;
/**
 *
 * @author jesus
 */
public class CtrlPersonaTrabajo {
    
    Connection con = null;
    PreparedStatement ps;
    ResultSet rs;
    
    public void crear(int Persona_idPersona, int Trabajo_idTrabajo){
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("INSERT INTO personaTrabajo (Trabajo_idTrabajo, Persona_idPersona) VALUES (?,?)");
        
            ps.setInt(1, Trabajo_idTrabajo);
            ps.setInt(2, Persona_idPersona);
            
            int res = ps.executeUpdate();
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlPersonaTrabajo: " + e.getMessage());
        }
    }
    
    public void editar(int Persona_idPersonaTrabajo, int Persona_idPersona, int Trabajo_idTrabajo){
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("UPDATE personaTrabajo SET Trabajo_idTrabajo = ? WHERE Persona_idPersonaTrabajo = ? AND "
                    + "Persona_idPersona = ?");
            
            ps.setInt(1, Trabajo_idTrabajo);
            ps.setInt(2, Persona_idPersonaTrabajo);
            ps.setInt(3, Persona_idPersona);

            int res = ps.executeUpdate();
            
            if(res > 0){
                //Nada de Nada :v
            }else{
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios");
            }
            
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlPersonaTrabajo: " + e.getMessage());
        }
    }
    
    
    public void borrar(int Persona_idPersonaTrabajo, int Trabajo_idTrabajo, int Persona_idPersona){
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("DELETE FROM personaTrabajo WHERE Persona_idPersonaTrabajo=? AND Persona_idPersona=? AND Trabajo_idTrabajo=?");
            
            ps.setInt(1, Persona_idPersonaTrabajo);
            ps.setInt(2, Persona_idPersona);
            ps.setInt(3, Trabajo_idTrabajo);
            
            int res = ps.executeUpdate();
            
            if(res > 0){
                //Nada de Nada :v
            }else{
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios");
            }
            
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlPersonaTrabajo: " + e.getMessage());
        }
    }
    
    
    public PersonaTrabajo leer(int Persona_idPersona, int Trabajo_idTrabajo){
        PersonaTrabajo personaTrabajo = new PersonaTrabajo();
        CtrlTrabajo ctrlTrabajo = new CtrlTrabajo();
        CtrlPersona ctrlPersona = new CtrlPersona();
        
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM personaTrabajo WHERE Persona_idPersona = ? AND Trabajo_idTrabajo=?");
           
            ps.setInt(1, Persona_idPersona);
            ps.setInt(2, Trabajo_idTrabajo);
            rs = ps.executeQuery();
            
            
            if (rs.next()) {
                personaTrabajo.setIdPersonaTrabajo(rs.getInt("Persona_idPersonaTrabajo"));
                personaTrabajo.setIdTrabajo(ctrlTrabajo.leer(rs.getInt("Trabajo_idTrabajo")));
                personaTrabajo.setIdPersona(ctrlPersona.leer(rs.getInt("Persona_idPersona")));
            }else{
                System.out.println("No encontrado en CtrlPersonaTrabajo.java");
            }
            
        } catch (HeadlessException | SQLException e) {
            System.out.println("Error CtrlPersonaTrabajo: " + e.getMessage());
        }
        return personaTrabajo;
    }
    
    public PersonaTrabajo leerIdTrabajo(int Persona_idPersona, int Persona_idPersonaTrabajo){
        PersonaTrabajo personaTrabajo = new PersonaTrabajo();
        CtrlTrabajo ctrlTrabajo = new CtrlTrabajo();
        CtrlPersona ctrlPersona = new CtrlPersona();
        
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM personaTrabajo WHERE Persona_idPersona = ? AND Persona_idPersonaTrabajo=?");
           
            ps.setInt(1, Persona_idPersona);
            ps.setInt(2, Persona_idPersonaTrabajo);
            rs = ps.executeQuery();
            
            
            if (rs.next()) {
                personaTrabajo.setIdPersonaTrabajo(rs.getInt("Persona_idPersonaTrabajo"));
                personaTrabajo.setIdTrabajo(ctrlTrabajo.leer(rs.getInt("Trabajo_idTrabajo")));
                personaTrabajo.setIdPersona(ctrlPersona.leer(rs.getInt("Persona_idPersona")));
            }else{
                System.out.println("No encontrado en CtrlPersonaTrabajo.java");
            }
            
        } catch (HeadlessException | SQLException e) {
            System.out.println("Error CtrlPersonaTrabajo: " + e.getMessage());
        }
        return personaTrabajo;
    }
    
    public void llenarLista(int Persona_idPersona, JList<Trabajo> lista){
        CtrlTrabajo ctrlTrabajo=new CtrlTrabajo();
        PersonaTrabajo personaTrabajo;
        
        DefaultListModel<Trabajo> modelo=new DefaultListModel<>();
        
        try{
            
            con=clases.Conectar.conexion();
            ps=(PreparedStatement)con.prepareStatement("SELECT * FROM personaTrabajo WHERE Persona_idPersona=?");
            ps.setInt(1, Persona_idPersona);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                personaTrabajo=new PersonaTrabajo();
                
                personaTrabajo.setIdTrabajo(ctrlTrabajo.leer(rs.getInt("Trabajo_idTrabajo")));
                
                modelo.addElement(personaTrabajo.getIdTrabajo());
            }
            
            lista.setModel(modelo);
            
            con.close();
        }catch(SQLException e){
            
        }
    }
    
    public void llenarTabla(int Persona_idPersona, JTable tabla) throws SQLException{
        
        con=clases.Conectar.conexion();
    
        ps=(PreparedStatement)con.prepareStatement("SELECT trabajo.detalle FROM trabajo"
                + " INNER JOIN personaTrabajo ON trabajo.idTrabajo=personaTrabajo.Trabajo_idTrabajo"
                + " WHERE personaTrabajo.Persona_idPersona=?");
        
        ps.setInt(1, Persona_idPersona);
        
        rs=ps.executeQuery();
        
        DefaultTableModel modelo =new DefaultTableModel();
        modelo.addColumn("Trabajo");
        
        tabla.setModel(modelo);
        
        String[] datos= new String[1];
        try{
            
            while(rs.next()){
                
	            datos[0]=rs.getString(1);
	            
            	    modelo.addRow(datos);
            }

             tabla.setModel(modelo);
         }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "ERROR AL CARGAR LAS LOCALIDADES EN LA TABLA"); 
        }
        
    }
}
