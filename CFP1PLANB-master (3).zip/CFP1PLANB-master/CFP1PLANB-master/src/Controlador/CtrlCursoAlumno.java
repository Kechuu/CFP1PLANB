/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.CursoAlumno;
import modelo.Lugar;
import modelo.TipoCurso;
/**
 *
 * @author jesus
 */
public class CtrlCursoAlumno {
    
    Connection con = null;
    PreparedStatement ps;
    ResultSet rs;
    
    public void crear(float saldo, java.util.Date fechaIngreso, int idAlumno, int idEstadoAlumno, int idCurso){
        
        java.sql.Date fecha1=new Date(fechaIngreso.getTime());
        
        try {
          
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("INSERT INTO cursoAlumno (costo,saldo,fechaIngreso,"
                    + "fechaBajaEgreso, Alumno_idAlumno,EstadoAlumno_idEstadoAlumno,Curso_idCurso) VALUES (?,?,?,?,?,?,?)");
            
            ps.setFloat(1, 0);
            ps.setFloat(2, saldo);
            ps.setDate(3, fecha1);
            ps.setDate(4, null);
            ps.setInt(5, idAlumno);
            ps.setInt(6, idEstadoAlumno);
            ps.setInt(7, idCurso);
            //ps.setInt(8, idMotivoBaja);
            
            int res = ps.executeUpdate();
            con.close();
           
        } catch (HeadlessException | SQLException e ) {
            JOptionPane.showMessageDialog(null, "ES CURSO ALUMNO!!!");
            System.out.println("Error CtrlCursoAlumno: " + e.getMessage());
        }        
    }
    
    public void editar(int idCursoAlumno, int idCurso){
        try{
            con=clases.Conectar.conexion();
            ps=(PreparedStatement)con.prepareStatement("UPDATE cursoAlumno SET Curso_idCurso =? WHERE idCursoAlumno = ?");
            ps.setInt(1, idCurso);
            ps.setInt(2, idCursoAlumno);
            
            ps.execute();
            
            con.close();
        }catch(SQLException e){
            
        }
    }
    
    public void alumnoBajaEgresado(int idAlumno,int idCurso, int idMotivoBaja,int idEstadoAlumno, java.util.Date fechaBajaEgreso){
        
        java.sql.Date fecha=new Date(fechaBajaEgreso.getTime());
        
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("UPDATE cursoAlumno SET fechaBajaEgreso = ?, MotivoBaja_idMotivoBaja = ?,"
                    + " EstadoAlumno_idEstadoAlumno = ? WHERE Alumno_idAlumno = ? AND Curso_idCurso = ?");
            
            ps.setDate(1, fecha);
            ps.setInt(2, idMotivoBaja);
            ps.setInt(3, idEstadoAlumno);
            ps.setInt(4, idAlumno);
            ps.setInt(5, idCurso);
            
            int res = ps.executeUpdate();
            con.close();
            
            if(res>0) JOptionPane.showMessageDialog(null, "Se realizo el cambio");
        } catch (Exception e) {
            System.out.println("Error CtrlCursoAlumno: " + e.getMessage());
        }
    }
    
    
    public void costo(int idAlumno,int idCurso, float costo, int cursoAlumno){
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("UPDATE cursoAlumno SET costo=? WHERE Alumno_idAlumno = ? AND Curso_idCurso = ? "
                    + " AND idCursoAlumno=? AND EstadoAlumno_idEstadoAlumno = 1");
            
            ps.setFloat(1, costo);
            ps.setInt(2, idAlumno);
            ps.setInt(3, idCurso);
            ps.setInt(4, cursoAlumno);
            int res = ps.executeUpdate();
            con.close();
            
        } catch (SQLException e) {
            System.out.println("Error CtrlCursoAlumno: " + e.getMessage());
        }
    }
    
    public void pagarSaldo(int idAlumno, int idCurso, float saldo, int cursoAlumno){
    
            try{
                con=clases.Conectar.conexion();
                ps=(PreparedStatement)con.prepareStatement("UPDATE cursoAlumno SET saldo=?"
                        + " WHERE Alumno_idAlumno=? AND Curso_idCurso=? AND idCursoAlumno=?");
                
                ps.setFloat(1, saldo);
                ps.setInt(2, idAlumno);
                ps.setInt(3, idCurso);
                ps.setInt(4, cursoAlumno);
                
                ps.execute();
                
                con.close();
            }catch(Exception e){
                
            }
    }
    
    public CursoAlumno leer(int idAlumno, int idCurso){
        CursoAlumno cursoAlumno = new CursoAlumno();
        CtrlAlumno ctrlAlumno = new CtrlAlumno();
        CtrlEstadoAlumno ctrlEstadoAlumno = new CtrlEstadoAlumno();
        CtrlCurso ctrlCurso = new CtrlCurso();
        CtrlMotivoBaja ctrlMotivoBaja = new CtrlMotivoBaja();
        
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM cursoAlumno WHERE Alumno_idAlumno=? AND Curso_idCurso=? AND EstadoAlumno_idEstadoAlumno=1");
            
            ps.setInt(1, idAlumno);
            ps.setInt(2, idCurso);
            
            rs = ps.executeQuery();
            
            if (rs.next()) {
                cursoAlumno.setIdCursoAlumno(rs.getInt("idCursoAlumno"));
                cursoAlumno.setCosto(rs.getFloat("costo"));
                cursoAlumno.setSaldo(rs.getFloat("saldo"));
                cursoAlumno.setFechaIngreso(rs.getDate("fechaIngreso"));
                cursoAlumno.setFechaBajaEgreso(rs.getDate("fechaBaja"));
                cursoAlumno.setIdAlumno(ctrlAlumno.leerId(rs.getInt("Alumno_idAlumno")));
                cursoAlumno.setIdEstadoAlumno(ctrlEstadoAlumno.leer(rs.getInt("EstadoAlumno_idEstadoAlumno")));
                cursoAlumno.setIdCurso(ctrlCurso.leerCurso(rs.getInt("Curso_idCurso")));
                //cursoAlumno.setIdMotivoBaja(ctrlMotivoBaja.leer(rs.getInt("MotivoBaja_idMotivoBaja")));
            }else{
                System.out.println("No encontrado en CtrlCursoAlumno.java");
            }
            
        } catch (Exception e) {
            System.out.println("Error CtrlCursoAlumno: " + e.getMessage());
        }
        
        return cursoAlumno;
    }
    
    public void llenarLista(int idAlumno, JList<TipoCurso>lista){
    //Este metodo llena lista de los cursos que esta cursando actualmente un determinado alumno
        DefaultListModel <TipoCurso> modelo=new DefaultListModel<>();
        
        try{
            con=clases.Conectar.conexion();
            ps=(PreparedStatement)con.prepareStatement("SELECT curso.idCurso, tipoCurso.detalle FROM cursoAlumno"
                    + " INNER JOIN curso ON cursoAlumno.Curso_idCurso = curso.idCurso"
                    + " INNER JOIN tipoCurso ON curso.TipoCurso_idTipoCurso = tipoCurso.idTipoCurso"
                    + " WHERE cursoAlumno.Alumno_idAlumno = ? AND cursoAlumno.EstadoAlumno_idEstadoAlumno = 1");
            ps.setInt(1, idAlumno);
            
            //ps=(PreparedStatement)con.prepareStatement("SELECT c");
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                TipoCurso tipoCurso=new TipoCurso();
                
                tipoCurso.setIdTipoCurso(rs.getInt("idCurso"));
                tipoCurso.setDetalle(rs.getString("detalle"));
                
                modelo.addElement(tipoCurso);
            }
            lista.setModel(modelo);
            
            con.close();
        }catch(Exception e){
            System.out.println("Error CtrlCursoAlumno: " + e.getMessage());
        }
        
    }
    
    public void cargarCombo(int idAlumno, JComboBox<TipoCurso> cbCurso){
        
        try {
            con=clases.Conectar.conexion();
            /*ps=(PreparedStatement)con.prepareStatement("SELECT tipoCurso.idTipoCurso, tipoCurso.detalle FROM cursoAlumno"
                    + " INNER JOIN curso ON cursoAlumno.Curso_idCurso = curso.idCurso"
                    + " INNER JOIN tipoCurso ON curso.TipoCurso_idTipoCurso = tipoCurso.idTipoCurso"
                    + " WHERE cursoAlumno.Alumno_idAlumno = ? AND cursoAlumno.EstadoAlumno_idEstadoAlumno=1");
            */
            ps=(PreparedStatement)con.prepareStatement("SELECT curso.idCurso, tipoCurso.detalle FROM cursoAlumno"
                    + " INNER JOIN curso ON cursoAlumno.Curso_idCurso = curso.idCurso"
                    + " INNER JOIN tipoCurso ON curso.TipoCurso_idTipoCurso = tipoCurso.idTipoCurso"
                    + " WHERE cursoAlumno.Alumno_idAlumno = ? AND cursoAlumno.EstadoAlumno_idEstadoAlumno = 1");
            
            ps.setInt(1, idAlumno);
            rs=ps.executeQuery();
            
            TipoCurso tipoCurso=new TipoCurso();
            tipoCurso.setIdTipoCurso(0);
            tipoCurso.setDetalle("Seleccione una opción...");
            cbCurso.addItem(tipoCurso);
            
            while (rs.next()) {      
                
                tipoCurso=new TipoCurso();
                
                tipoCurso.setIdTipoCurso(rs.getInt("idCurso"));
                tipoCurso.setDetalle(rs.getString("detalle"));
                
                cbCurso.addItem(tipoCurso);
            }
            
        } catch (SQLException ex) {
               
        }
        
    }
    
    public void llenarTabla(int idAlumno, JTable tabla) throws SQLException{
        
        con=clases.Conectar.conexion();
    
        ps=(PreparedStatement)con.prepareStatement("SELECT tipoCurso.detalle, estadoAlumno.detalle FROM tipoCurso "
                + " INNER JOIN curso ON tipoCurso.idTipoCurso = curso.TipoCurso_idTipoCurso "
                + " INNER JOIN cursoAlumno ON curso.idCurso= cursoAlumno.Curso_idCurso "
                + " INNER JOIN estadoAlumno ON cursoAlumno.EstadoAlumno_idEstadoAlumno=estadoAlumno.idEstadoAlumno "
                + " WHERE cursoAlumno.Alumno_idAlumno=?");
        
        ps.setInt(1, idAlumno);
        
        rs=ps.executeQuery();
        
        DefaultTableModel modelo =new DefaultTableModel();
        modelo.addColumn("Nombre");
        modelo.addColumn("Estado Alumno");
        
        tabla.setModel(modelo);
        
        String[] datos= new String[2];
        try{
            
            while(rs.next()){

	            datos[0]=rs.getString(1);
	            datos[1]=rs.getString(2);
	            
            	    modelo.addRow(datos);
            }

            con.close();
            tabla.setModel(modelo);
         }
        catch(SQLException ex){
           
        }
        
    }
    
    public void borradoLogico(int idAlumno, int idMotivo, java.util.Date fecha){
        CtrlCurso ctrlCurso=new CtrlCurso();
        CtrlAlumno ctrlAlumno=new CtrlAlumno();
        CtrlPersona ctrlPersona=new CtrlPersona();
        
        CursoAlumno cursoAlumno;
        Vector<CursoAlumno> vector = new Vector<>();
        
        try{
            con=clases.Conectar.conexion();
            ps=(PreparedStatement)con.prepareStatement("SELECT * FROM cursoAlumno"
                    + " WHERE Alumno_idAlumno = ? AND EstadoAlumno_idEstadoAlumno = 1");
            ps.setInt(1, idAlumno);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                cursoAlumno=new CursoAlumno();
                
                cursoAlumno.setIdCursoAlumno(rs.getInt("idCursoAlumno"));
                cursoAlumno.setIdCurso(ctrlCurso.leerCurso(rs.getInt("Curso_idCurso")));
                
                vector.add(cursoAlumno);
            }
         
    //public void alumnoBajaEgresado(int idAlumno,int idCurso, int idMotivoBaja,int idEstadoAlumno, java.util.Date fechaBajaEgreso){
            java.sql.Date fechaS=new Date(fecha.getTime());
        
            for(int i=0; i<vector.size(); i++){
                alumnoBajaEgresado(idAlumno, vector.get(i).getIdCurso().getIdCurso(), idMotivo, 2, fechaS);
            }
    //HAY QUE VERIFICAR SI ESTA DADO DE BAJA SI LOS CURSOS EN QUE ESTÁ SIGUE ACTIVO        
            ctrlPersona.borrar(ctrlAlumno.leerId(idAlumno).getIdPersona().getIdPersona());
            ctrlAlumno.borrar(ctrlAlumno.leerId(idAlumno).getIdPersona().getIdPersona(), idAlumno);
            
        }catch(SQLException e){
            
        }
    }
    
    public void llenarListaBaja(int idAlumno, JList<TipoCurso> lista){
    DefaultListModel<TipoCurso> modelo = new DefaultListModel<>();
    try{
        con = clases.Conectar.conexion();
        ps = (PreparedStatement) con.prepareStatement("SELECT curso.idCurso, tipoCurso.detalle FROM cursoAlumno"
                + " INNER JOIN curso ON cursoAlumno.Curso_idCurso = curso.idCurso"
                + " INNER JOIN tipoCurso ON curso.TipoCurso_idTipoCurso = tipoCurso.idTipoCurso"
                + " WHERE cursoAlumno.Alumno_idAlumno = ? AND cursoAlumno.EstadoAlumno_idEstadoAlumno != 1");
        ps.setInt(1, idAlumno);
        rs = ps.executeQuery();
        while(rs.next()){
            TipoCurso tipoCurso = new TipoCurso();
            tipoCurso.setIdTipoCurso(rs.getInt("idCurso"));
            tipoCurso.setDetalle(rs.getString("detalle"));
            modelo.addElement(tipoCurso);
        }
        lista.setModel(modelo);
        con.close();
    }catch(Exception e){
        System.out.println("Error llenarListaBaja: " + e.getMessage());
    }
}
}