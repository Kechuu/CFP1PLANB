/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import modelo.Cargo;
import modelo.EmpleadoCargo;
import modelo.EmpleadoTitulo;
import modelo.Titulo;
/**
 *
 * @author jesus
 */
public class CtrlEmpleadoCargo {
    
    Connection con = null;
    PreparedStatement ps;
    ResultSet rs;
    
    public void crear(int Cargo_idCargo, int Empleado_idEmpleado){
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("INSERT INTO empleadoCargo (Cargo_idCargo,Empleado_idEmpleado) VALUES (?,?)");
        
            ps.setInt(1, Cargo_idCargo);
            ps.setInt(2, Empleado_idEmpleado);
            
            int res = ps.executeUpdate();
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlEmpleadoCargo: " + e.getMessage());
        }
    }
    
    public void modificarCargo(int Empleado_idEmpleadoCargo, int Cargo_idCargo, int Empleado_idEmpleado){
        try {
            con = clases.Conectar.conexion();
            ps = (PreparedStatement) con.prepareStatement("UPDATE empleadoCargo SET Cargo_idCargo = ? WHERE Empleado_idEmpleadoCargo = ? AND Empleado_idEmpleado = ? ");
        
            ps.setInt(1, Cargo_idCargo);
            ps.setInt(2, Empleado_idEmpleadoCargo);
            ps.setInt(3, Empleado_idEmpleado);
            
             int res = ps.executeUpdate();
            
            if(res > 0){
                //Nada de Nada :v
            }else{
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios");
            }
            
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlEmpleadoCargo: " + e.getMessage());
        }
    }
    
    public void borrar(int Empleado_idEmpleadoCargo, int Cargo_idCargo, int Empleado_idEmpleado){
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("DELETE FROM empleadoCargo WHERE Empleado_idEmpleadoCargo=? AND Empleado_idEmpleado=? AND Cargo_idCargo=?");
            
            ps.setInt(1, Empleado_idEmpleadoCargo);
            ps.setInt(2, Empleado_idEmpleado);
            ps.setInt(3, Cargo_idCargo);
            
            int res = ps.executeUpdate();
            
            if(res > 0){
                //Nada de Nada :v
            }else{
                JOptionPane.showMessageDialog(null, "Error al guardar los cambios");
            }
            
            con.close();
            
        } catch (Exception e) {
            System.out.println("Error CtrlEmpleadoCargo: " + e.getMessage());
        }
    }
    
    public EmpleadoCargo leer(int Empleado_idEmpleadoCargo){
        EmpleadoCargo empleadoCargo = new EmpleadoCargo();
        CtrlCargo ctrlCargo = new CtrlCargo();
        CtrlEmpleado ctrlEmpleado = new CtrlEmpleado();
        
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM empleadoCargo WHERE Empleado_idEmpleadoCargo = ?");
            
            ps.setInt(1, Empleado_idEmpleadoCargo);
            
            rs = ps.executeQuery();
            
            if (rs.next()) {
                empleadoCargo.setIdCargo(ctrlCargo.leer(rs.getInt("Cargo_idCargo")));
                empleadoCargo.setIdEmpleado(ctrlEmpleado.leer(rs.getInt("Empleado_idEmpleado")));
            }else{
                System.out.println("No encontrado en CtrlEmpleadoCargo.java");
            }
            
        } catch (Exception e) {
            System.out.println("Error CtrlEmpleadoCargo: " + e.getMessage());
        }
        return empleadoCargo;
    }
    
    public EmpleadoCargo leer(int Empleado_idEmpleado, int Cargo_idCargo){
        
        EmpleadoCargo empleadoCargo=new EmpleadoCargo();
        CtrlEmpleado ctrlEmpleado=new CtrlEmpleado();
        CtrlCargo ctrlCargo=new CtrlCargo();
        
        try {
            con = clases.Conectar.conexion();
            ps =  (PreparedStatement) con.prepareStatement("SELECT * FROM empleadoCargo WHERE Empleado_idEmpleado = ? AND Cargo_idCargo=?");
            
            ps.setInt(1, Empleado_idEmpleado);
            ps.setInt(2, Cargo_idCargo);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                empleadoCargo=new EmpleadoCargo();
                
                empleadoCargo.setEmpleadoCargo(rs.getInt("Empleado_idEmpleadoCargo"));
                empleadoCargo.setIdEmpleado(ctrlEmpleado.leerIdEmpleado(rs.getInt("Empleado_idEmpleado")));
                empleadoCargo.setIdCargo(ctrlCargo.leer(rs.getInt("Cargo_idCargo")));
                
            }    
            con.close();
        } catch (SQLException e) {
            System.out.println("Error CtrlEmpleadoCargo: " + e.getMessage());
        }
        
        return empleadoCargo;
    }
    
        public void llenarLista(int Empleado_idEmpleado, JList <Cargo> lista){
        CtrlCargo ctrlCargo=new CtrlCargo();
        EmpleadoCargo empleadoCargo;
        
        DefaultListModel<Cargo> modelo=new DefaultListModel<>();
        
        try{
            con=clases.Conectar.conexion();
            ps=(PreparedStatement)con.prepareStatement("SELECT * FROM empleadoCargo WHERE Empleado_idEmpleado=?");
            ps.setInt(1, Empleado_idEmpleado);
            
            rs=ps.executeQuery();
            
            while(rs.next()){
                empleadoCargo=new EmpleadoCargo();
                
                empleadoCargo.setIdCargo(ctrlCargo.leer(rs.getInt("Cargo_idCargo")));
                modelo.addElement(empleadoCargo.getIdCargo());
            }
            
            lista.setModel(modelo);
            con.close();
        }catch(SQLException e){
            
        }
        
    }
}
